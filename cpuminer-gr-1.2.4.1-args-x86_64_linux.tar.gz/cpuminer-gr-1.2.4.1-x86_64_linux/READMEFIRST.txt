IMPORTAINT ***UPDATED WALLET TO YOU ADDRESS IN config.json "user" USE NOTEPAD OR TEXT EDITOR

After wallet update:

open terminal run command "sudo ./cpuminer.sh" will start your miner.

-REPLACE tune_config WITH YOUR FILE OR RUN A NEW SYSTEM TEST (*sample file will work with all systems).

UPDATED JAN.10.2022
-UPDATED config.json
    -HASH MONITOR
    -COLOR MONITOR
    -THREAD COUNT

-FILE UPDATED
  
-CLEAN-UP  
-*LOW STALE SHARE RATE 
-**VERY LOW REJECTED SHARE RATE

 
