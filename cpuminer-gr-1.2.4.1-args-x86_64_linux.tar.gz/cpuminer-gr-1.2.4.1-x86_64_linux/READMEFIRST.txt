UPDATED JAN.10.2022

IMPORTAINT ***UPDATED WALLET TO YOUR ADDRESS IN config.json "user" USE NOTEPAD OR TEXT EDITOR

After wallet update:


To Start Software

If asked for libcurl please open terminal and run command "sudo apt install curl -y" 

Open terminal in the cpuminer folder and run "sudo ./cpuminer.sh" will start your miner as administrator.


To Exit Software 

Please use "Ctrl c" to exit the software try not to X out as it sometimes does not exit correctly and will require a restart of the system. 







 
