UPDATED JAN.10.2022

IMPORTAINT ***UPDATED WALLET TO YOUR ADDRESS IN config.json "user" USE NOTEPAD OR TEXT EDITOR

After wallet update:


To Start Software

Right click "cpuminer.bat" run as administrator will start your miner.

-REPLACE tune_config WITH YOUR FILE OR RUN A NEW SYSTEM TEST (*sample file will work with all systems).


To Exit Software 

Please use "Ctrl c" to exit the software try not to X out as it sometimes does not exit correctly and will require a restart of the system.



 
